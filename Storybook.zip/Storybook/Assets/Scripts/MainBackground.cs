using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainBackground : MonoBehaviour
{
    public Button Button;

    // Start is called before the first frame update
    void Start()
    {
        Button.Reset();
    }

}
