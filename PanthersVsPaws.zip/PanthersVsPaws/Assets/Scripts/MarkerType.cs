public enum MarkerType
{
    None,       // 0
    Paw,        // 1
    Panther,
    Tie
}