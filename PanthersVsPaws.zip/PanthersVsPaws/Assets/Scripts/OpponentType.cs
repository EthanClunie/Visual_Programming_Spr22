public enum OpponentType
{
    Human,
    EasyCPU,
    HardCPU
}